public class Main {

    public static void main(String[] args) {
        Principal principal = new Principal();
        principal.menu();
    }
}
