public record Moneda(String codigo, Double valor) {
}
